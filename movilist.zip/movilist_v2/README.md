- Authentification + bdd (Firebase pas encore implémenté)
- Pages crées et routées
- Firebase installé (google + facebook) : ID = contact.originaltomc@gmail.com
                        PW = 987aBx2x