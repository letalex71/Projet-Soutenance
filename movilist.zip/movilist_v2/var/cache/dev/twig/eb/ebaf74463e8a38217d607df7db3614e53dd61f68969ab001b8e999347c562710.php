<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* main/movie-view.html.twig */
class __TwigTemplate_55c5cd7dfce23c396eeaae7d28e42995024d8eb5ecfb411d74e5cf3da2ace7c9 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'stylesheets' => [$this, 'block_stylesheets'],
            'body' => [$this, 'block_body'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 2
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "main/movie-view.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "main/movie-view.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "main/movie-view.html.twig", 2);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo " ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 4
    public function block_stylesheets($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 5
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "<main class=\"page projects-page\">
    <img class=\"backdrop\" src=\"\">
    <section class=\"portfolio-block photography \">
        <div class=\"row \">
            <img class=\"offset-1 col-md-3 img-fluid image poster\" src=\"\">
            <div class=\"offset-1 col-md-7 border-bottom\">
                <!-- Synopsis -->
                <h4 class=\"text-center\"><ins>Synopsis</ins></h4>
                <p class=\"text-center overview\"></p>
                <div class=\"container\">
                    <div class=\"d-flex justify-content-center align-items-center content\">
                        <h3>Ratings</h3>
                    </div>
                </div>
            </div>
        </div>
        <div class=\"row\">
            <div class=\"offset-1 col-md-3 mt-2\">
                <!-- Example split danger button -->
                <div class=\"btn-group dropdown\">
                    <button type=\"button\" id=\"add-to-list\" class=\"btn btn-sm btn-primary add-to-list\">Ajouter à
                        ma liste</button>
                    <button type=\"button\" id=\"add-to-list-dd\"
                        class=\"btn btn-sm btn-primary dropdown-toggle dropdown-toggle-split\" data-toggle=\"dropdown\"
                        aria-haspopup=\"true\" aria-expanded=\"false\">
                        <span class=\"sr-only\">Toggle Dropdown</span>
                    </button>
                    <div class=\"dropdown-menu\">
                        <a class=\"dropdown-item\" href=\"#\">Action</a>
                        <a class=\"dropdown-item\" href=\"#\">Another action</a>
                        <a class=\"dropdown-item\" href=\"#\">Something else here</a>
                        <div class=\"dropdown-divider\"></div>
                        <a class=\"dropdown-item\" href=\"#\">Separated link</a>
                    </div>
                </div>
                <button class=\"btn btn-sm btn-danger\" id=\"like\"><i class=\"fas fa-heart\"></i></button>
            </div>
        </div>
    </section>
    <section class=\"portfolio-block call-to-action border-bottom\">

    </section>
    <section class=\"portfolio-block photography gradient\">
        <div class=\"row no-gutters\">
            <div class=\"offset-1 col-md-2 container-fluid border-bottom text-wrap\">
                <h4 class=\"text-center\"><ins>Détails</ins></h4>
                <span class=\"country\"><ins>Pays : </ins></span>
                <span class=\"studio\"><ins>Studios : </ins></span>
                <span class=\"year\"><ins>Année : </ins></span>
                <!-- <ul class=\"casting\"></ul> -->
                <span class=\"revenues\"><ins>Recettes : </ins></span>
                <span class=\"budget\"><ins>Budget : </ins></span>
            </div>
            <div class=\"offset-2 col-md-5 container-fluid border-bottom\">
                <!-- Casting -->
                <nav>
                    <div class=\"nav nav-tabs justify-content-center\" id=\"nav-tab\" role=\"tablist\">
                        <a class=\"nav-item nav-link active\" id=\"nav-cast-tab\" data-toggle=\"tab\" href=\"#nav-cast\"
                            role=\"tab\" aria-controls=\"nav-cast\" aria-selected=\"true\">
                            <h4>Casting</h4>
                        </a>
                        <a class=\"nav-item nav-link\" id=\"nav-crew-tab\" data-toggle=\"tab\" href=\"#nav-crew\" role=\"tab\"
                            aria-controls=\"nav-crew\" aria-selected=\"false\">
                            <h4>Equipe</h4>
                        </a>
                    </div>
                </nav>
                <div class=\"tab-content\" id=\"nav-tabContent\">
                    <div class=\"tab-pane fade show active\" id=\"nav-cast\" role=\"tabpanel\" aria-labelledby=\"nav-cast-tab\">
                        <ul class=\"list-group-cast\">
                        </ul>
                    </div>
                    <div class=\"tab-pane fade show\" id=\"nav-crew\" role=\"tabpanel\" aria-labelledby=\"nav-crew-tab\">
                        <ul class=\"list-group-crew\">
                        </ul>
                    </div>
                </div>  
                <!-- Casting -->
            </div>
        </div>
    </section>
</main>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 89
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        // line 90
        echo "<script>
    displayMovie();
</script>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "main/movie-view.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  210 => 90,  200 => 89,  108 => 6,  98 => 5,  80 => 4,  61 => 3,  38 => 2,);
    }

    public function getSourceContext()
    {
        return new Source("{# pages/movie-view.html.twig #}
{% extends \"base.html.twig\" %}
{% block title %} {% endblock %}
{% block stylesheets %}{% endblock %}
{% block body %}
<main class=\"page projects-page\">
    <img class=\"backdrop\" src=\"\">
    <section class=\"portfolio-block photography \">
        <div class=\"row \">
            <img class=\"offset-1 col-md-3 img-fluid image poster\" src=\"\">
            <div class=\"offset-1 col-md-7 border-bottom\">
                <!-- Synopsis -->
                <h4 class=\"text-center\"><ins>Synopsis</ins></h4>
                <p class=\"text-center overview\"></p>
                <div class=\"container\">
                    <div class=\"d-flex justify-content-center align-items-center content\">
                        <h3>Ratings</h3>
                    </div>
                </div>
            </div>
        </div>
        <div class=\"row\">
            <div class=\"offset-1 col-md-3 mt-2\">
                <!-- Example split danger button -->
                <div class=\"btn-group dropdown\">
                    <button type=\"button\" id=\"add-to-list\" class=\"btn btn-sm btn-primary add-to-list\">Ajouter à
                        ma liste</button>
                    <button type=\"button\" id=\"add-to-list-dd\"
                        class=\"btn btn-sm btn-primary dropdown-toggle dropdown-toggle-split\" data-toggle=\"dropdown\"
                        aria-haspopup=\"true\" aria-expanded=\"false\">
                        <span class=\"sr-only\">Toggle Dropdown</span>
                    </button>
                    <div class=\"dropdown-menu\">
                        <a class=\"dropdown-item\" href=\"#\">Action</a>
                        <a class=\"dropdown-item\" href=\"#\">Another action</a>
                        <a class=\"dropdown-item\" href=\"#\">Something else here</a>
                        <div class=\"dropdown-divider\"></div>
                        <a class=\"dropdown-item\" href=\"#\">Separated link</a>
                    </div>
                </div>
                <button class=\"btn btn-sm btn-danger\" id=\"like\"><i class=\"fas fa-heart\"></i></button>
            </div>
        </div>
    </section>
    <section class=\"portfolio-block call-to-action border-bottom\">

    </section>
    <section class=\"portfolio-block photography gradient\">
        <div class=\"row no-gutters\">
            <div class=\"offset-1 col-md-2 container-fluid border-bottom text-wrap\">
                <h4 class=\"text-center\"><ins>Détails</ins></h4>
                <span class=\"country\"><ins>Pays : </ins></span>
                <span class=\"studio\"><ins>Studios : </ins></span>
                <span class=\"year\"><ins>Année : </ins></span>
                <!-- <ul class=\"casting\"></ul> -->
                <span class=\"revenues\"><ins>Recettes : </ins></span>
                <span class=\"budget\"><ins>Budget : </ins></span>
            </div>
            <div class=\"offset-2 col-md-5 container-fluid border-bottom\">
                <!-- Casting -->
                <nav>
                    <div class=\"nav nav-tabs justify-content-center\" id=\"nav-tab\" role=\"tablist\">
                        <a class=\"nav-item nav-link active\" id=\"nav-cast-tab\" data-toggle=\"tab\" href=\"#nav-cast\"
                            role=\"tab\" aria-controls=\"nav-cast\" aria-selected=\"true\">
                            <h4>Casting</h4>
                        </a>
                        <a class=\"nav-item nav-link\" id=\"nav-crew-tab\" data-toggle=\"tab\" href=\"#nav-crew\" role=\"tab\"
                            aria-controls=\"nav-crew\" aria-selected=\"false\">
                            <h4>Equipe</h4>
                        </a>
                    </div>
                </nav>
                <div class=\"tab-content\" id=\"nav-tabContent\">
                    <div class=\"tab-pane fade show active\" id=\"nav-cast\" role=\"tabpanel\" aria-labelledby=\"nav-cast-tab\">
                        <ul class=\"list-group-cast\">
                        </ul>
                    </div>
                    <div class=\"tab-pane fade show\" id=\"nav-crew\" role=\"tabpanel\" aria-labelledby=\"nav-crew-tab\">
                        <ul class=\"list-group-crew\">
                        </ul>
                    </div>
                </div>  
                <!-- Casting -->
            </div>
        </div>
    </section>
</main>
{% endblock %}
{% block javascripts %}
<script>
    displayMovie();
</script>
{% endblock %}", "main/movie-view.html.twig", "C:\\Users\\conta\\Documents\\github\\movilist symfony\\movilist_v2\\templates\\main\\movie-view.html.twig");
    }
}
