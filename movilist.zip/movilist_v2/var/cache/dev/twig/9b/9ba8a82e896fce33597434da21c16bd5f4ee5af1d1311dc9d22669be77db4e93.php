<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* security/login.html.twig */
class __TwigTemplate_02f11e09f3bb6995f05bb3939903eeaec851a6b9c566c2792e6da37791bd1f40 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "security/login.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "security/login.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "security/login.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Connexion";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 5
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "<main class=\"page projects-page\">
    <section class=\"portfolio-block projects-with-sidebar\">
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-lg-10 col-xl-9 mx-auto\">
                    <div class=\"card card-signin flex-row my-2\">
                        <div class=\"card-img-left d-none d-md-flex\">
                            <!-- Background image for card set in CSS! -->
                        </div>
                        <div class=\"card-body\">
                            <form class=\"form-signin\" method=\"post\">
                                <h1 class=\"h3 mb-3 font-weight-normal text-center\">Connexion</h1>
                                ";
        // line 18
        if ((isset($context["error"]) || array_key_exists("error", $context) ? $context["error"] : (function () { throw new RuntimeError('Variable "error" does not exist.', 18, $this->source); })())) {
            // line 19
            echo "                                <div class=\"alert alert-danger\">
                                    ";
            // line 20
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(twig_get_attribute($this->env, $this->source, (isset($context["error"]) || array_key_exists("error", $context) ? $context["error"] : (function () { throw new RuntimeError('Variable "error" does not exist.', 20, $this->source); })()), "messageKey", [], "any", false, false, false, 20), twig_get_attribute($this->env, $this->source, (isset($context["error"]) || array_key_exists("error", $context) ? $context["error"] : (function () { throw new RuntimeError('Variable "error" does not exist.', 20, $this->source); })()), "messageData", [], "any", false, false, false, 20), "security"), "html", null, true);
            echo "</div>
                                ";
        }
        // line 22
        echo "                                ";
        if (twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 22, $this->source); })()), "user", [], "any", false, false, false, 22)) {
            // line 23
            echo "                                <div class=\"mb-3 alert alert-danger\">
                                    Vous êtes déjà connectés en tant que ";
            // line 24
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 24, $this->source); })()), "user", [], "any", false, false, false, 24), "username", [], "any", false, false, false, 24), "html", null, true);
            echo ". <a class=\"text-info\"
                                        href=\"";
            // line 25
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_logout");
            echo "\">Voulez-vous vous connecter avec un autre compte ?</a>
                                </div>
                                ";
        }
        // line 28
        echo "                                <label for=\"inputEmail\">Email</label>
                                <input type=\"email\" value=\"";
        // line 29
        echo twig_escape_filter($this->env, (isset($context["last_username"]) || array_key_exists("last_username", $context) ? $context["last_username"] : (function () { throw new RuntimeError('Variable "last_username" does not exist.', 29, $this->source); })()), "html", null, true);
        echo "\" name=\"email\" id=\"inputEmail\"
                                    class=\"form-control\" placeholder=\"Adresse email\" required autofocus>
                                <label for=\"inputPassword\">Mot de passe</label>
                                <input type=\"password\" name=\"password\" id=\"inputPassword\" class=\"form-control\" placeholder=\"Mot de passe\" required>
                                <input type=\"checkbox\" id=\"remember_me\" name=\"_remember_me\" />
                                <label for=\"remember_me\">Se souvenir de moi</label>
                                <input type=\"hidden\" name=\"_csrf_token\" value=\"";
        // line 35
        echo twig_escape_filter($this->env, $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderCsrfToken("authenticate"), "html", null, true);
        echo "\">
                                <button class=\"btn btn-sm btn-primary btn-block text-uppercase\" type=\"submit\">
                                    Connexion
                                </button>
                            <a class=\"d-block text-center mt-2 small\" href=\"#\" data-target=\"#pwdModal\"
                                    data-toggle=\"modal\">Mot de passe oublié?</a>
                                    <p class=\"d-block text-center mt-2 small\">Pas encore de compte ? <a class=\"text-info\"
                                        href=\"";
        // line 42
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_logout");
        echo "\">Cliquez ici pour vous enregistrer</a></p>
                                <hr class=\"my-4\">
                                <button class=\"btn btn-sm btn-danger btn-google btn-block text-uppercase\"
                                    type=\"submit\"><i class=\"fab fa-google mr-2\"></i>Connexion avec
                                    Google</button>
                                <button class=\"btn btn-sm btn-info btn-facebook btn-block text-uppercase\"
                                    type=\"submit\"><i class=\"fab fa-facebook-f mr-2\"></i>Connexion avec
                                    Facebook</button>
                                </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div id=\"pwdModal\" class=\"modal fade\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
            <div class=\"modal-dialog\">
                <div class=\"modal-content\">
                    <button type=\"button\" class=\"close text-danger bg-white\" data-dismiss=\"modal\" aria-hidden=\"true\">X</button>
                    <div class=\"modal-header\">
                        <h1 class=\"text-center\">Mot de passe oublié?</h1>
                    </div>
                    <div class=\"modal-body\">
                        <div class=\"col-md-12\">
                            <div class=\"panel panel-default\">
                                <div class=\"panel-body\">
                                    <div>
                                        <p>Entrez votre adresse email</p>
                                        <div class=\"panel-body\">
                                            <fieldset>
                                                <div class=\"form-group\">
                                                    <input class=\"form-control input-lg\" placeholder=\"Adresse email\"
                                                        name=\"email\" type=\"email\">
                                                </div>
                                                <input class=\"btn btn-sm btn-primary btn-block\"
                                                    value=\"Envoyer un nouveau mot de passe\" type=\"submit\">
                                            </fieldset>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
    </section>
</main>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "security/login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  150 => 42,  140 => 35,  131 => 29,  128 => 28,  122 => 25,  118 => 24,  115 => 23,  112 => 22,  107 => 20,  104 => 19,  102 => 18,  88 => 6,  78 => 5,  59 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block title %}Connexion{% endblock %}

{% block body %}
<main class=\"page projects-page\">
    <section class=\"portfolio-block projects-with-sidebar\">
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-lg-10 col-xl-9 mx-auto\">
                    <div class=\"card card-signin flex-row my-2\">
                        <div class=\"card-img-left d-none d-md-flex\">
                            <!-- Background image for card set in CSS! -->
                        </div>
                        <div class=\"card-body\">
                            <form class=\"form-signin\" method=\"post\">
                                <h1 class=\"h3 mb-3 font-weight-normal text-center\">Connexion</h1>
                                {% if error %}
                                <div class=\"alert alert-danger\">
                                    {{ error.messageKey|trans(error.messageData, 'security') }}</div>
                                {% endif %}
                                {% if app.user %}
                                <div class=\"mb-3 alert alert-danger\">
                                    Vous êtes déjà connectés en tant que {{ app.user.username }}. <a class=\"text-info\"
                                        href=\"{{ path('app_logout') }}\">Voulez-vous vous connecter avec un autre compte ?</a>
                                </div>
                                {% endif %}
                                <label for=\"inputEmail\">Email</label>
                                <input type=\"email\" value=\"{{ last_username }}\" name=\"email\" id=\"inputEmail\"
                                    class=\"form-control\" placeholder=\"Adresse email\" required autofocus>
                                <label for=\"inputPassword\">Mot de passe</label>
                                <input type=\"password\" name=\"password\" id=\"inputPassword\" class=\"form-control\" placeholder=\"Mot de passe\" required>
                                <input type=\"checkbox\" id=\"remember_me\" name=\"_remember_me\" />
                                <label for=\"remember_me\">Se souvenir de moi</label>
                                <input type=\"hidden\" name=\"_csrf_token\" value=\"{{ csrf_token('authenticate') }}\">
                                <button class=\"btn btn-sm btn-primary btn-block text-uppercase\" type=\"submit\">
                                    Connexion
                                </button>
                            <a class=\"d-block text-center mt-2 small\" href=\"#\" data-target=\"#pwdModal\"
                                    data-toggle=\"modal\">Mot de passe oublié?</a>
                                    <p class=\"d-block text-center mt-2 small\">Pas encore de compte ? <a class=\"text-info\"
                                        href=\"{{ path('app_logout') }}\">Cliquez ici pour vous enregistrer</a></p>
                                <hr class=\"my-4\">
                                <button class=\"btn btn-sm btn-danger btn-google btn-block text-uppercase\"
                                    type=\"submit\"><i class=\"fab fa-google mr-2\"></i>Connexion avec
                                    Google</button>
                                <button class=\"btn btn-sm btn-info btn-facebook btn-block text-uppercase\"
                                    type=\"submit\"><i class=\"fab fa-facebook-f mr-2\"></i>Connexion avec
                                    Facebook</button>
                                </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div id=\"pwdModal\" class=\"modal fade\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
            <div class=\"modal-dialog\">
                <div class=\"modal-content\">
                    <button type=\"button\" class=\"close text-danger bg-white\" data-dismiss=\"modal\" aria-hidden=\"true\">X</button>
                    <div class=\"modal-header\">
                        <h1 class=\"text-center\">Mot de passe oublié?</h1>
                    </div>
                    <div class=\"modal-body\">
                        <div class=\"col-md-12\">
                            <div class=\"panel panel-default\">
                                <div class=\"panel-body\">
                                    <div>
                                        <p>Entrez votre adresse email</p>
                                        <div class=\"panel-body\">
                                            <fieldset>
                                                <div class=\"form-group\">
                                                    <input class=\"form-control input-lg\" placeholder=\"Adresse email\"
                                                        name=\"email\" type=\"email\">
                                                </div>
                                                <input class=\"btn btn-sm btn-primary btn-block\"
                                                    value=\"Envoyer un nouveau mot de passe\" type=\"submit\">
                                            </fieldset>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
    </section>
</main>
{% endblock %}", "security/login.html.twig", "C:\\Users\\conta\\Documents\\github\\movilist symfony\\movilist_v2\\templates\\security\\login.html.twig");
    }
}
