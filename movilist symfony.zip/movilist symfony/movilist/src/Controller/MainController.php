<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use AppBundle\AppBundle;
use AppBundle\Entity\user;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Routing\Annotation\Route;

class MainController extends AbstractController
{
    /**
     * @Route("/", name="discover")
     */
    public function index()
    {
        return $this->render('pages/discover.html.twig');
    }
    /**
     * @Route("/rechercher", name="search")
     */
    public function search()
    {
        return $this->render('pages/search.html.twig');
    }
    /**
     * @Route("/forum", name="forum")
     */
    public function forum()
    {
        return $this->render('/forum/forum.html.twig');
    }
    /**
     * @Route("/profil", name="profile")
     */
    public function profile()
    {
        return $this->render('pages/profile.html.twig');
    }
    /**
     * @Route("/se-connecter", name="login")
     */
    public function login()
    {
        return $this->render('pages/login.html.twig');
    }
    /**
     * @Route("/s-enregistrer", name="register")
     */
    public function register()
    {
        return $this->render('pages/register.html.twig');
    }
    /**
     * @Route("/contactez-nous", name="contact")
     */
    public function contact()
    {
        return $this->render('pages/contact.html.twig');
    }

    /**
     * @Route("/series", name="displayShow")
     */
    public function displayShow()
    {
        return $this->render('pages/show-view.html.twig');
    }

    /**
     * @Route("/films", name="displayMovie")
     */
    public function displayMovie()
    {
        return $this->render('pages/movie-view.html.twig');
    }
    /**
     * @Route("/personnes/{id}", name="people")
     */
    public function displayPeople()
    {
        return $this->render('pages/people-view.html.twig');
    }
}
