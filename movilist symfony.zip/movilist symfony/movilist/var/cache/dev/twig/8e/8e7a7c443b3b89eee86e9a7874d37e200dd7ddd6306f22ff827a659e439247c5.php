<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* pages/login.html.twig */
class __TwigTemplate_3ad008150ad82f4134a74a85d6268f201d52668971c06f1cdc39ee5231d2da8b extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'stylesheets' => [$this, 'block_stylesheets'],
            'body' => [$this, 'block_body'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 2
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "pages/login.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "pages/login.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "pages/login.html.twig", 2);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Se connecter ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 4
    public function block_stylesheets($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 5
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "<main class=\"page projects-page\">
    <section class=\"portfolio-block projects-with-sidebar\">
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-lg-10 col-xl-9 mx-auto\">
                    <div class=\"card card-signin flex-row my-5\">
                        <div class=\"card-img-left d-none d-md-flex\">
                            <!-- Background image for card set in CSS! -->
                        </div>
                        <div class=\"card-body\">
                            <h5 class=\"card-title text-center\">Se connecter</h5>
                            <form class=\"form-signin\">
                                <div class=\"form-label-group\">
                                    <label for=\"inputUserame\">Pseudonyme</label>
                                    <input type=\"text\" id=\"inputUserame\" class=\"form-control\"
                                        placeholder=\"Pseudonyme\" required autofocus>
                                </div>
                                <div class=\"form-label-group\">
                                    <label for=\"inputPassword\">Mot de passe</label>
                                    <input type=\"password\" id=\"inputPassword\" class=\"form-control\"
                                        placeholder=\"Mot de passe\" required>
                                </div>
                                <button class=\"btn btn-sm btn-primary btn-block text-uppercase mt-3\"
                                    type=\"submit\">Se connecter</button>
                                <a class=\"d-block text-center mt-2 small\" href=\"#\" data-target=\"#pwdModal\"
                                    data-toggle=\"modal\">Mot de passe oublié?</a>
                                    <p class=\"d-block text-center mt-2 small\">Pas encore de compte ? <a href=\"";
        // line 32
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("register");
        echo "\">Cliquez ici pour vous enregistrer</a></p>
                                <hr class=\"my-4\">
                                <button class=\"btn btn-sm btn-danger btn-google btn-block text-uppercase\"
                                    type=\"submit\"><i class=\"fab fa-google mr-2\"></i>Connexion avec
                                    Google</button>
                                <button class=\"btn btn-sm btn-info btn-facebook btn-block text-uppercase\"
                                    type=\"submit\"><i class=\"fab fa-facebook-f mr-2\"></i>Connexion avec
                                    Facebook</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div id=\"pwdModal\" class=\"modal fade\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
            <div class=\"modal-dialog\">
                <div class=\"modal-content\">
                    <div class=\"modal-header\">
                        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-hidden=\"true\">×</button>
                        <h1 class=\"text-center\">Mot de passe oublié?</h1>
                    </div>
                    <div class=\"modal-body\">
                        <div class=\"col-md-12\">
                            <div class=\"panel panel-default\">
                                <div class=\"panel-body\">
                                    <div class=\"text-center\">
                                        <p>Entrez votre adresse email</p>
                                        <div class=\"panel-body\">
                                            <fieldset>
                                                <div class=\"form-group\">
                                                    <input class=\"form-control input-lg\" placeholder=\"Adresse email\"
                                                        name=\"email\" type=\"email\">
                                                </div>
                                                <input class=\"btn btn-sm btn-primary btn-block\"
                                                    value=\"Envoyer un nouveau mot de passe\" type=\"submit\">
                                            </fieldset>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
    </section>
</main>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 77
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "pages/login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  191 => 77,  136 => 32,  108 => 6,  98 => 5,  80 => 4,  61 => 3,  38 => 2,);
    }

    public function getSourceContext()
    {
        return new Source("{# pages/login.html.twig #}
{% extends \"base.html.twig\" %}
{% block title %}Se connecter {% endblock %}
{% block stylesheets %}{% endblock %}
{% block body %}
<main class=\"page projects-page\">
    <section class=\"portfolio-block projects-with-sidebar\">
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-lg-10 col-xl-9 mx-auto\">
                    <div class=\"card card-signin flex-row my-5\">
                        <div class=\"card-img-left d-none d-md-flex\">
                            <!-- Background image for card set in CSS! -->
                        </div>
                        <div class=\"card-body\">
                            <h5 class=\"card-title text-center\">Se connecter</h5>
                            <form class=\"form-signin\">
                                <div class=\"form-label-group\">
                                    <label for=\"inputUserame\">Pseudonyme</label>
                                    <input type=\"text\" id=\"inputUserame\" class=\"form-control\"
                                        placeholder=\"Pseudonyme\" required autofocus>
                                </div>
                                <div class=\"form-label-group\">
                                    <label for=\"inputPassword\">Mot de passe</label>
                                    <input type=\"password\" id=\"inputPassword\" class=\"form-control\"
                                        placeholder=\"Mot de passe\" required>
                                </div>
                                <button class=\"btn btn-sm btn-primary btn-block text-uppercase mt-3\"
                                    type=\"submit\">Se connecter</button>
                                <a class=\"d-block text-center mt-2 small\" href=\"#\" data-target=\"#pwdModal\"
                                    data-toggle=\"modal\">Mot de passe oublié?</a>
                                    <p class=\"d-block text-center mt-2 small\">Pas encore de compte ? <a href=\"{{ path('register') }}\">Cliquez ici pour vous enregistrer</a></p>
                                <hr class=\"my-4\">
                                <button class=\"btn btn-sm btn-danger btn-google btn-block text-uppercase\"
                                    type=\"submit\"><i class=\"fab fa-google mr-2\"></i>Connexion avec
                                    Google</button>
                                <button class=\"btn btn-sm btn-info btn-facebook btn-block text-uppercase\"
                                    type=\"submit\"><i class=\"fab fa-facebook-f mr-2\"></i>Connexion avec
                                    Facebook</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div id=\"pwdModal\" class=\"modal fade\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">
            <div class=\"modal-dialog\">
                <div class=\"modal-content\">
                    <div class=\"modal-header\">
                        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-hidden=\"true\">×</button>
                        <h1 class=\"text-center\">Mot de passe oublié?</h1>
                    </div>
                    <div class=\"modal-body\">
                        <div class=\"col-md-12\">
                            <div class=\"panel panel-default\">
                                <div class=\"panel-body\">
                                    <div class=\"text-center\">
                                        <p>Entrez votre adresse email</p>
                                        <div class=\"panel-body\">
                                            <fieldset>
                                                <div class=\"form-group\">
                                                    <input class=\"form-control input-lg\" placeholder=\"Adresse email\"
                                                        name=\"email\" type=\"email\">
                                                </div>
                                                <input class=\"btn btn-sm btn-primary btn-block\"
                                                    value=\"Envoyer un nouveau mot de passe\" type=\"submit\">
                                            </fieldset>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
    </section>
</main>
{% endblock %}
{% block javascripts %}{% endblock %}", "pages/login.html.twig", "C:\\Users\\conta\\Documents\\github\\movilist symfony\\movilist\\templates\\pages\\login.html.twig");
    }
}
