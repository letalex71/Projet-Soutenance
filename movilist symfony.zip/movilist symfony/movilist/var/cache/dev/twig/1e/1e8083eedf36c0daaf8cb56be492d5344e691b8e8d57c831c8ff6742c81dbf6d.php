<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* pages/register.html.twig */
class __TwigTemplate_da778cc57874cdfd0eae912895238620c7de8c82e7643a6e34fd744e1803a8f1 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'stylesheets' => [$this, 'block_stylesheets'],
            'body' => [$this, 'block_body'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 2
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "pages/register.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "pages/register.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "pages/register.html.twig", 2);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Créer un compte ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 4
    public function block_stylesheets($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 5
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "<main class=\"page projects-page\">
    <section class=\"portfolio-block projects-with-sidebar\">
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-lg-10 col-xl-9 mx-auto\">
                    <div class=\"card card-signin flex-row my-5\">
                        <div class=\"card-img-left d-none d-md-flex\">
                            <!-- Background image for card set in CSS! -->
                        </div>
                        <div class=\"card-body\">
                            <h5 class=\"card-title text-center\">Enregistrement</h5>
                            <form class=\"form-signin\">
                                <div class=\"form-label-group\">
                                    <label for=\"inputUserame\">Pseudonyme</label>
                                    <input type=\"text\" id=\"inputUserame\" class=\"form-control\"
                                        placeholder=\"Pseudonyme\" required autofocus>
                                </div>
                                <div class=\"form-label-group\">
                                    <label for=\"inputEmail\">Adresse email</label>
                                    <input type=\"email\" id=\"inputEmail\" class=\"form-control\"
                                        placeholder=\"Adresse email\" required>
                                </div>
                                <hr>
                                <div class=\"form-label-group\">
                                    <label for=\"inputPassword\">Mot de passe</label>
                                    <input type=\"password\" id=\"inputPassword\" class=\"form-control\"
                                        placeholder=\"Mot de passe\" required>
                                </div>
                                <div class=\"form-label-group\">
                                    <label for=\"inputConfirmPassword\">Confirmation mot de passe</label>
                                    <input type=\"password\" id=\"inputConfirmPassword\" class=\"form-control\"
                                        placeholder=\"Confirmation mot de passe\" required>
                                </div>
                                <button class=\"btn btn-sm btn-primary btn-block text-uppercase mt-3\"
                                    type=\"submit\">S'enregistrer</button>
                                    <p class=\"d-block text-center mt-2 small\">Déjà un compte ? <a href=\"";
        // line 41
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("login");
        echo "\">Cliquez ici pour vous connecter</a></p>                                <hr class=\"my-4\">
                                <button class=\"btn btn-sm btn-danger btn-google btn-block text-uppercase\"
                                    type=\"submit\"><i class=\"fab fa-google mr-2\"></i>Connexion avec
                                    Google</button>
                                <button class=\"btn btn-sm btn-info btn-facebook btn-block text-uppercase\"
                                    type=\"submit\"><i class=\"fab fa-facebook-f mr-2\"></i>Connexion avec
                                    Facebook</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 57
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "pages/register.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  171 => 57,  145 => 41,  108 => 6,  98 => 5,  80 => 4,  61 => 3,  38 => 2,);
    }

    public function getSourceContext()
    {
        return new Source("{# pages/register.html.twig #}
{% extends \"base.html.twig\" %}
{% block title %}Créer un compte {% endblock %}
{% block stylesheets %}{% endblock %}
{% block body %}
<main class=\"page projects-page\">
    <section class=\"portfolio-block projects-with-sidebar\">
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-lg-10 col-xl-9 mx-auto\">
                    <div class=\"card card-signin flex-row my-5\">
                        <div class=\"card-img-left d-none d-md-flex\">
                            <!-- Background image for card set in CSS! -->
                        </div>
                        <div class=\"card-body\">
                            <h5 class=\"card-title text-center\">Enregistrement</h5>
                            <form class=\"form-signin\">
                                <div class=\"form-label-group\">
                                    <label for=\"inputUserame\">Pseudonyme</label>
                                    <input type=\"text\" id=\"inputUserame\" class=\"form-control\"
                                        placeholder=\"Pseudonyme\" required autofocus>
                                </div>
                                <div class=\"form-label-group\">
                                    <label for=\"inputEmail\">Adresse email</label>
                                    <input type=\"email\" id=\"inputEmail\" class=\"form-control\"
                                        placeholder=\"Adresse email\" required>
                                </div>
                                <hr>
                                <div class=\"form-label-group\">
                                    <label for=\"inputPassword\">Mot de passe</label>
                                    <input type=\"password\" id=\"inputPassword\" class=\"form-control\"
                                        placeholder=\"Mot de passe\" required>
                                </div>
                                <div class=\"form-label-group\">
                                    <label for=\"inputConfirmPassword\">Confirmation mot de passe</label>
                                    <input type=\"password\" id=\"inputConfirmPassword\" class=\"form-control\"
                                        placeholder=\"Confirmation mot de passe\" required>
                                </div>
                                <button class=\"btn btn-sm btn-primary btn-block text-uppercase mt-3\"
                                    type=\"submit\">S'enregistrer</button>
                                    <p class=\"d-block text-center mt-2 small\">Déjà un compte ? <a href=\"{{ path('login') }}\">Cliquez ici pour vous connecter</a></p>                                <hr class=\"my-4\">
                                <button class=\"btn btn-sm btn-danger btn-google btn-block text-uppercase\"
                                    type=\"submit\"><i class=\"fab fa-google mr-2\"></i>Connexion avec
                                    Google</button>
                                <button class=\"btn btn-sm btn-info btn-facebook btn-block text-uppercase\"
                                    type=\"submit\"><i class=\"fab fa-facebook-f mr-2\"></i>Connexion avec
                                    Facebook</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
{% endblock %}
{% block javascripts %}{% endblock %}", "pages/register.html.twig", "C:\\Users\\conta\\Documents\\github\\movilist symfony\\movilist\\templates\\pages\\register.html.twig");
    }
}
