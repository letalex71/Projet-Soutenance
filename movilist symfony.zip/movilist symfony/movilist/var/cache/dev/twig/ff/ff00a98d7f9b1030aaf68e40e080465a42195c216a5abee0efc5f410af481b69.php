<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* pages/search.html.twig */
class __TwigTemplate_820264832efc7c2e3faa65c564d371cbdb386e4b85cdafd48679ac2b49516beb extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'stylesheets' => [$this, 'block_stylesheets'],
            'body' => [$this, 'block_body'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 2
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "pages/search.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "pages/search.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "pages/search.html.twig", 2);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Rechercher ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 4
    public function block_stylesheets($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 5
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "<main class=\"page projects-page\">
    <div class=\"row\">
        <div class=\"col-8 offset-2\">
            <div class=\"input-group md-form form-sm form-2 pl-0\">
                <input class=\"form-control my-0 py-1 red-border\" type=\"text\" placeholder=\"Rechercher\" aria-label=\"Search\">
                <div class=\"input-group-append\">
                    <span class=\"input-group-text red lighten-3\" id=\"basic-text1\"><i class=\"fas fa-search text-grey\"
                            aria-hidden=\"true\"></i></span>
                </div>
            </div>
        </div>
    </div>
    
    <section class=\"portfolio-block projects-with-sidebar\">
        <!-- Start: portfolio heading -->
        <!-- End: portfolio heading -->
        <div class=\"row\">
            <div class=\"col-3\">
                <div class=\"nav flex-column nav-pills\" id=\"v-pills-tab\" role=\"tablist\" aria-orientation=\"vertical\">
                    <h5 class=\"nav-link \" id=\"v-pills-filter-tab\" data-toggle=\"pill\" href=\"#v-pills-filter\"
                        role=\"tab\" aria-controls=\"v-pills-filter\" aria-selected=\"false\">Filtres</h5>
                    <a class=\"nav-link active\" id=\"v-pills-movie-tab\" data-toggle=\"pill\" href=\"#v-pills-movie\"
                        role=\"tab\" aria-controls=\"v-pills-movie\" aria-selected=\"true\">Film</a>
                    <a class=\"nav-link\" id=\"v-pills-shows-tab\" data-toggle=\"pill\" href=\"#v-pills-shows\" role=\"tab\"
                        aria-controls=\"v-pills-shows\" aria-selected=\"false\">Série</a>
                    <a class=\"nav-link\" id=\"v-pills-actors-tab\" data-toggle=\"pill\" href=\"#v-pills-actors\" role=\"tab\"
                        aria-controls=\"v-pills-actors\" aria-selected=\"false\">Acteur</a>
                </div>
            </div>
            <div class=\"col-9\">
                <div class=\"tab-content\" id=\"v-pills-tabContent\">
                    <div class=\"tab-pane fade show active\" id=\"v-pills-movie\" role=\"tabpanel\"
                        aria-labelledby=\"v-pills-movie-tab\">
                        <h6>En utilisant ce filtre, l'appel API se fera à nouveau pour n'afficher que les
                            résultats correspondant à un film.</h6>
                    </div>
                    <div class=\"tab-pane fade\" id=\"v-pills-shows\" role=\"tabpanel\"
                        aria-labelledby=\"v-pills-shows-tab\">
                        <h6>En utilisant ce filtre, l'appel API se fera à nouveau pour n'afficher que les
                            résultats correspondant à une série.</h6>
                    </div>
                    <div class=\"tab-pane fade\" id=\"v-pills-actors\" role=\"tabpanel\"
                        aria-labelledby=\"v-pills-actors-tab\">
                        <h6>En utilisant ce filtre, l'appel API se fera à nouveau pour n'afficher que les
                            résultats correspondant un acteur.</h6>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 57
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "pages/search.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  168 => 57,  108 => 6,  98 => 5,  80 => 4,  61 => 3,  38 => 2,);
    }

    public function getSourceContext()
    {
        return new Source("{# pages/search.html.twig #}
{% extends \"base.html.twig\" %}
{% block title %}Rechercher {% endblock %}
{% block stylesheets %}{% endblock %}
{% block body %}
<main class=\"page projects-page\">
    <div class=\"row\">
        <div class=\"col-8 offset-2\">
            <div class=\"input-group md-form form-sm form-2 pl-0\">
                <input class=\"form-control my-0 py-1 red-border\" type=\"text\" placeholder=\"Rechercher\" aria-label=\"Search\">
                <div class=\"input-group-append\">
                    <span class=\"input-group-text red lighten-3\" id=\"basic-text1\"><i class=\"fas fa-search text-grey\"
                            aria-hidden=\"true\"></i></span>
                </div>
            </div>
        </div>
    </div>
    
    <section class=\"portfolio-block projects-with-sidebar\">
        <!-- Start: portfolio heading -->
        <!-- End: portfolio heading -->
        <div class=\"row\">
            <div class=\"col-3\">
                <div class=\"nav flex-column nav-pills\" id=\"v-pills-tab\" role=\"tablist\" aria-orientation=\"vertical\">
                    <h5 class=\"nav-link \" id=\"v-pills-filter-tab\" data-toggle=\"pill\" href=\"#v-pills-filter\"
                        role=\"tab\" aria-controls=\"v-pills-filter\" aria-selected=\"false\">Filtres</h5>
                    <a class=\"nav-link active\" id=\"v-pills-movie-tab\" data-toggle=\"pill\" href=\"#v-pills-movie\"
                        role=\"tab\" aria-controls=\"v-pills-movie\" aria-selected=\"true\">Film</a>
                    <a class=\"nav-link\" id=\"v-pills-shows-tab\" data-toggle=\"pill\" href=\"#v-pills-shows\" role=\"tab\"
                        aria-controls=\"v-pills-shows\" aria-selected=\"false\">Série</a>
                    <a class=\"nav-link\" id=\"v-pills-actors-tab\" data-toggle=\"pill\" href=\"#v-pills-actors\" role=\"tab\"
                        aria-controls=\"v-pills-actors\" aria-selected=\"false\">Acteur</a>
                </div>
            </div>
            <div class=\"col-9\">
                <div class=\"tab-content\" id=\"v-pills-tabContent\">
                    <div class=\"tab-pane fade show active\" id=\"v-pills-movie\" role=\"tabpanel\"
                        aria-labelledby=\"v-pills-movie-tab\">
                        <h6>En utilisant ce filtre, l'appel API se fera à nouveau pour n'afficher que les
                            résultats correspondant à un film.</h6>
                    </div>
                    <div class=\"tab-pane fade\" id=\"v-pills-shows\" role=\"tabpanel\"
                        aria-labelledby=\"v-pills-shows-tab\">
                        <h6>En utilisant ce filtre, l'appel API se fera à nouveau pour n'afficher que les
                            résultats correspondant à une série.</h6>
                    </div>
                    <div class=\"tab-pane fade\" id=\"v-pills-actors\" role=\"tabpanel\"
                        aria-labelledby=\"v-pills-actors-tab\">
                        <h6>En utilisant ce filtre, l'appel API se fera à nouveau pour n'afficher que les
                            résultats correspondant un acteur.</h6>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>{% endblock %}
{% block javascripts %}{% endblock %}", "pages/search.html.twig", "C:\\Users\\conta\\Documents\\github\\movilist symfony\\movilist\\templates\\pages\\search.html.twig");
    }
}
